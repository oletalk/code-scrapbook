README Moonfruit exercise

This zip file should contain:

Moonfruit Exercise CM.pdf - Design document/discussion for the Fish Tank exercise
moonfruit - folder containing the source
moonfruit/tests - Test scripts and classes

If you would like to run a test, please run it from the 'moonfruit' directory. E.g.,
$ perl tests/DiverFish_tests.pl

The tests/user_test.pl shows a test case where many fish are added and eventually die out.

All of the tests for the domain classes e.g. Level_tests.pl, DiverFish_test.pl should work.
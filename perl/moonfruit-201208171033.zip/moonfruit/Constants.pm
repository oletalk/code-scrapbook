package Constants;

use constant DEPTH_SURFACE => 0;
use constant DEPTH_TOP     => 10;
use constant DEPTH_MIDDLE  => 30;
use constant DEPTH_BOTTOM  => 50;

use constant DEFAULT_VITALITY_FISH => 30;
use constant DEFAULT_VITALITY_SNAIL => 50;
use constant VITALITY_DEAD => 0;
use constant VITALITY_REMOVED => -1; # dead but also no longer in the tank

use constant DEFAULT_CAPACITY => 10;

use constant START_TEMPERATURE => 20;
use constant PIRANHA_MIN_TEMP => 15;

1;
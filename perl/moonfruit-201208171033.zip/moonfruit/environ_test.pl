#!/usr/bin/perl

use Environment;
use PiranhaFish;

my $e = Environment->new();
my $p = PiranhaFish->new();

print $e->get_temperature();
$p->expire;
$e->add_dead_creature($p); # should fail

my $x = $e->give_dead_creature;
use Data::Dumper;
print "A dead creature: " . Dumper($x) . "\n";

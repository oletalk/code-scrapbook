package ClockworkFish;
$VERSION = 1.00;

use base Fish;
use strict;

sub breathes {
	0;
}

sub eats {
	0;
}

1;
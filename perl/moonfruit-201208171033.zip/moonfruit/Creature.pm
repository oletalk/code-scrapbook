package Creature;
$VERSION = 1.00;

use strict;
use Constants;

sub new {
	my $class = shift;
	my ($vitality) = @_;
	bless {
		'vitality' => $vitality
	}, $class;
}

sub swimsAtDepth {
	1;
}

sub pass_time {
	my $self = shift;
	my $v = $self->{'vitality'};
	$v-- if $v > 0;
	$self->{'vitality'} = $v;
}

sub suffocate {
	my $self = shift;
	if ($self->isAlive && $self->breathes) {
		$self->expire;
	}
}

sub expire {
	my $self = shift;
	$self->{'vitality'} = Constants::VITALITY_DEAD;
}

sub breathes {
	1; # most creatures breathe
}

sub eats {
	1; # most creatures eat
}

sub eat {
	my $self = shift;
	if ($self->isAlive && $self->eats) {
		print "eating...\n";
	}
}

sub isAlive {
	my $self = shift;
	$self->{'vitality'} > Constants::VITALITY_DEAD;
}

sub canBeRemoved {
	my $self = shift;
	$self->{'vitality'} <= Constants::VITALITY_REMOVED;
}

1;
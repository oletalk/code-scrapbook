package Environment;

use Constants;
use Creature;

use Carp;
use strict;

sub new {
	my $class = shift;
	my @dead_creatures = ();
	bless {
		'temperature' => Constants::START_TEMPERATURE,
		'foodamount' => 0,
		'dead_creatures' => \@dead_creatures
	}, $class;	

}

sub get_foodamount {
	my $self = shift;
	$self->{'foodamount'};
}

sub give_food {
	my $self = shift;
	my ($food_req) = @_;
	if ($self->{'foodamount'}  >= $food_req) {
		$self->{'foodamount'} -= $food_req;
	}
	$food_req;
}

sub add_food {
	my $self = shift;
	my ($foodamt) = @_;
	if ($foodamt > 0) {
		$self->{'foodamount'} += $foodamt;
		print "Added food, amount $foodamt \n";
	}
}

sub change_temperature {
	my $self = shift;
	my ($newtemp) = @_;
	$self->{'temperature'} = $newtemp;
}

sub get_temperature {
	my $self = shift;
	$self->{'temperature'};
}

sub add_dead_creature {
	my $self = shift;
	my (@creatures) = @_;
	foreach my $dc (@creatures) {
		if ($dc->isAlive) {
			carp "Can't add a live creature into dead_creatures list";
		} else {
			push @{$self->{'dead_creatures'}}, $dc;
		}
	}
}

sub give_dead_creature {
	my $self = shift;
	my $ret = undef;
	
	$ret = pop @{$self->{'dead_creatures'}};
}

1;
package PiranhaFish;

use base Fish;
use Carp;
use Constants;
use strict;

# CM 16/8 22:40 TODO: when does the Piranha eat??

sub eat_fish {
	my $self = shift;
	my ($fish) = @_;
	if ($fish->isa('Fish')) {
		print "Munch munch munch...\n";
		$fish->getEaten;
	} else {
		carp "Victim is not a Fish"; # carp! fish! :-D
	}
}

sub pass_time {
	my $self = shift;
	my ( $env ) = @_;
	
	my $temp = $env->get_temperature();
	$self->SUPER::pass_time();
	if ($self->isAlive && $temp < Constants::PIRANHA_MIN_TEMP) {
		$self->expire;
	}
}

1;